﻿using System;
using System.Windows;
using ATMApplication;  // Import backend 

namespace ATMAppWPF
{
    public partial class MainWindow : Window
    {
        private ATM atm;
        private BankAccount currentAccount;

        public MainWindow()
        {
            InitializeComponent();
            atm = new ATM();  
        }

        // Create Account Button 
        private void CreateAccountButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = AccountHolderTextBox.Text;
                if (string.IsNullOrEmpty(name))
                {
                    CreateAccountMessage.Text = "Name is required.";
                    return;
                }

                if (!double.TryParse(InitialBalanceTextBox.Text, out double initialBalance) || initialBalance < 0)
                {
                    CreateAccountMessage.Text = "Invalid balance amount.";
                    return;
                }

                string password = PasswordTextBox.Password;
                if (string.IsNullOrEmpty(password))
                {
                    CreateAccountMessage.Text = "Password is required.";
                    return;
                }

                currentAccount = atm.CreateAccount(name, initialBalance, password);
                CreateAccountMessage.Text = "Account created successfully!";
                ClearCreateAccountFields();
            }
            catch (Exception ex)
            {
                CreateAccountMessage.Text = $"Error: {ex.Message}";
            }
        }

        // Login Button 
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!int.TryParse(AccountNumberTextBox.Text, out int accountNumber))
                {
                    LoginMessage.Text = "Invalid account number.";
                    return;
                }

                string password = LoginPasswordTextBox.Password;
                if (string.IsNullOrEmpty(password))
                {
                    LoginMessage.Text = "Password is required.";
                    return;
                }

                currentAccount = atm.GetAccount(accountNumber, password);
                LoginMessage.Text = "Login successful!";
                ClearLoginFields();
                ShowAccountOperations();
            }
            catch (Exception ex)
            {
                LoginMessage.Text = $"Error: {ex.Message}";
            }
        }

        // Deposit Button 
        private void DepositButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!double.TryParse(AmountTextBox.Text, out double depositAmount) || depositAmount <= 0)
                {
                    OperationsMessage.Text = "Invalid deposit amount.";
                    return;
                }

                currentAccount.Deposit(depositAmount);
                OperationsMessage.Text = $"Deposited: {depositAmount:C}. New balance: {currentAccount.GetBalance():C}";
                ClearAmountTextBox();
            }
            catch (Exception ex)
            {
                OperationsMessage.Text = $"Error: {ex.Message}";
            }
        }

        // Withdraw Button 
        private void WithdrawButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!double.TryParse(AmountTextBox.Text, out double withdrawAmount) || withdrawAmount <= 0)
                {
                    OperationsMessage.Text = "Invalid withdrawal amount.";
                    return;
                }

                currentAccount.Withdraw(withdrawAmount);
                OperationsMessage.Text = $"Withdrew: {withdrawAmount:C}. New balance: {currentAccount.GetBalance():C}";
                ClearAmountTextBox();
            }
            catch (Exception ex)
            {
                OperationsMessage.Text = $"Error: {ex.Message}";
            }
        }

        // Show Transactions Button 
        private void ShowTransactionsButton_Click(object sender, RoutedEventArgs e)
        {
            string transactions = string.Join("\n", currentAccount.GetTransactions());
            MessageBox.Show("Transactions:\n" + transactions);
        }

        // Logout Button Click
        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            currentAccount = null;
            OperationsMessage.Text = "Logged out successfully!";
            ShowLoginPage();
        }

        // Clear fields after every action on the interface
        private void ClearCreateAccountFields()
        {
            AccountHolderTextBox.Clear();
            InitialBalanceTextBox.Clear();
            PasswordTextBox.Clear();
        }

        
        private void ClearLoginFields()
        {
            AccountNumberTextBox.Clear();
            LoginPasswordTextBox.Clear();
        }

        
        private void ClearAmountTextBox()
        {
            AmountTextBox.Clear();
        }

        // Show Account Operations Tab
        private void ShowAccountOperations()
        {
            TabControl.SelectedIndex = 2;  
        }

        // Show Login Tab
        private void ShowLoginPage()
        {
            TabControl.SelectedIndex = 1; 
        }
    }
}
